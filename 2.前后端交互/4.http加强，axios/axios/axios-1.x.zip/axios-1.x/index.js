import axios from './lib/axios.js';
export default axios;
